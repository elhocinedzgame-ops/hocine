import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Safely initialize API only if key exists, otherwise we return mocks or empty
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export interface WordDetails {
  task1Usage: string;
  task2Usage: string;
  synonyms: string[];
  nuance: string;
}

export const getWordExplanation = async (word: string, contextSentence: string): Promise<WordDetails | null> => {
  if (!ai) {
    console.warn("Gemini API Key not found");
    return null;
  }

  try {
    const prompt = `
      I am learning IELTS vocabulary. The word is "${word}".
      
      Please provide:
      1. An example sentence using this word suitable for IELTS Writing Task 1 (Academic Report, describing data/trends/process). If the word is not typically used in Task 1, provide a formal academic sentence.
      2. An example sentence using this word suitable for IELTS Writing Task 2 (Discursive Essay).
      3. A list of 3-4 high-level synonyms suitable for IELTS.
      4. A brief note on its nuance or a common collocation.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            task1Usage: { type: Type.STRING, description: "Example sentence for IELTS Task 1" },
            task2Usage: { type: Type.STRING, description: "Example sentence for IELTS Task 2" },
            synonyms: { type: Type.ARRAY, items: { type: Type.STRING } },
            nuance: { type: Type.STRING, description: "Brief explanation of meaning/nuance" }
          }
        }
      }
    });

    if (response.text) {
        return JSON.parse(response.text) as WordDetails;
    }
    return null;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};