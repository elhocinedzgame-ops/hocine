import { UserProgress, WordStatus, Word } from '../types';
import { INITIAL_WORDS } from '../constants';

const STORAGE_KEY = 'ielts_app_progress_v1';

export const getStoredProgress = (): Record<string, UserProgress> => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : {};
};

export const saveProgress = (progress: Record<string, UserProgress>) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
};

export const initializeProgress = (wordId: string): UserProgress => {
  return {
    wordId,
    status: WordStatus.New,
    interval: 0,
    reviews: 0,
    lastReviewDate: null,
    nextReviewDate: Date.now(),
    mistakes: 0,
  };
};

export const updateWordProgress = (
  currentProgress: UserProgress,
  isCorrect: boolean
): UserProgress => {
  const now = Date.now();
  let newInterval = currentProgress.interval;
  let newStatus = currentProgress.status;
  
  if (isCorrect) {
    // Spaced Repetition Algorithm (Simplified SuperMemo)
    if (newInterval === 0) {
      newInterval = 1; // 1 Day
    } else if (newInterval === 1) {
      newInterval = 3; // 3 Days
    } else {
      newInterval = Math.ceil(newInterval * 2.5); // Exponential growth
    }

    newStatus = WordStatus.Learned;
  } else {
    // Reset on mistake
    newInterval = 0;
    newStatus = WordStatus.FixMistakes;
  }

  const nextReviewDate = now + (newInterval * 24 * 60 * 60 * 1000);

  return {
    ...currentProgress,
    status: newStatus,
    interval: newInterval,
    reviews: currentProgress.reviews + 1,
    lastReviewDate: now,
    nextReviewDate: isCorrect ? nextReviewDate : now, // If wrong, review immediately/soon
    mistakes: isCorrect ? currentProgress.mistakes : currentProgress.mistakes + 1,
  };
};

export const getDueWords = (
  allWords: Word[],
  progressMap: Record<string, UserProgress>,
  filterDifficulty: string,
  filterTopic: string
): Word[] => {
  const now = Date.now();
  
  const eligibleWords = allWords.filter(word => {
    // Filter logic
    if (filterDifficulty !== 'All' && word.difficulty !== filterDifficulty) return false;
    if (filterTopic !== 'All' && word.topic !== filterTopic) return false;
    
    const userProg = progressMap[word.id];
    
    // If no progress, it's a new word, ready to learn
    if (!userProg) return true;

    // If it's "Fix Mistakes", prioritize it
    if (userProg.status === WordStatus.FixMistakes) return true;

    // Check if due date has passed
    return userProg.nextReviewDate <= now;
  });

  // Sort: Fix Mistakes -> Due Learned -> New
  return eligibleWords.sort((a, b) => {
    const progA = progressMap[a.id];
    const progB = progressMap[b.id];

    const typeA = progA?.status === WordStatus.FixMistakes ? 0 : (!progA ? 2 : 1);
    const typeB = progB?.status === WordStatus.FixMistakes ? 0 : (!progB ? 2 : 1);

    if (typeA !== typeB) return typeA - typeB;

    return 0; // Maintain default order otherwise
  });
};
