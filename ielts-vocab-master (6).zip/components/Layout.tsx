import React, { useState } from 'react';
import { Menu, X, BookOpen, BarChart2, List, Settings } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activePage: string;
  onNavigate: (page: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activePage, onNavigate }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const NavItem = ({ page, icon: Icon, label }: { page: string, icon: any, label: string }) => (
    <button
      onClick={() => {
        onNavigate(page);
        setIsSidebarOpen(false);
      }}
      className={`flex items-center w-full px-6 py-4 transition-colors ${
        activePage === page 
          ? 'bg-teal-50 text-teal-700 border-r-4 border-teal-600' 
          : 'text-slate-600 hover:bg-slate-50'
      }`}
    >
      <Icon className="w-5 h-5 mr-3" />
      <span className="font-medium">{label}</span>
    </button>
  );

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b z-20 flex items-center justify-between px-4">
        <div className="font-bold text-xl text-teal-700">IELTS Master</div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-slate-600">
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 w-64 bg-white border-r z-40 transform transition-transform duration-200 ease-in-out
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="h-16 flex items-center px-6 border-b">
          <span className="text-2xl font-bold text-teal-700 tracking-tight">IELTS Master</span>
        </div>

        <nav className="mt-6">
          <NavItem page="dashboard" icon={BarChart2} label="Dashboard" />
          <NavItem page="practice" icon={BookOpen} label="Practice Mode" />
          <NavItem page="list" icon={List} label="Word List" />
        </nav>
        
        <div className="absolute bottom-8 px-6 w-full">
           <div className="p-4 bg-teal-50 rounded-xl">
             <h4 className="text-sm font-semibold text-teal-800 mb-1">Pro Tip</h4>
             <p className="text-xs text-teal-600">Practice 10 minutes daily to improve retention by 40%.</p>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:pt-0 pt-16 overflow-y-auto h-screen">
        <div className="max-w-5xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;