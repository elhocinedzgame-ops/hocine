import React, { useMemo } from 'react';
import { Word, UserProgress, Difficulty, Topic, WordStatus } from '../types';
import { Search, Filter, Book, AlertTriangle, CheckCircle, Circle } from 'lucide-react';

interface WordListProps {
  words: Word[];
  progress: Record<string, UserProgress>;
  updateProgress: (wordId: string, isCorrect: boolean) => void;
  filters: {
    difficulty: string;
    topic: string;
    status: string;
    search: string;
  };
  setFilters: React.Dispatch<React.SetStateAction<{
    difficulty: string;
    topic: string;
    status: string;
    search: string;
  }>>;
}

const WordList: React.FC<WordListProps> = ({ words, progress, filters, setFilters }) => {
  const filteredWords = useMemo(() => {
    return words.filter(word => {
      const matchesSearch = word.english.toLowerCase().includes(filters.search.toLowerCase()) || 
                            word.arabic.includes(filters.search);
      const matchesDiff = filters.difficulty === 'All' || word.difficulty === filters.difficulty;
      const matchesTopic = filters.topic === 'All' || word.topic === filters.topic;
      
      const userProg = progress[word.id];
      const matchesStatus = filters.status === 'All' || 
                            (filters.status === 'Not Started' && !userProg) ||
                            (filters.status === userProg?.status);

      return matchesSearch && matchesDiff && matchesTopic && matchesStatus;
    });
  }, [words, progress, filters]);

  const getStatusBadge = (wordId: string) => {
    const prog = progress[wordId];
    if (!prog) return <span className="flex items-center text-slate-400"><Circle className="w-3 h-3 mr-1" /> New</span>;
    
    switch (prog.status) {
      case WordStatus.Learned:
        return <span className="flex items-center text-emerald-600"><CheckCircle className="w-3 h-3 mr-1" /> Learned</span>;
      case WordStatus.FixMistakes:
        return <span className="flex items-center text-red-600"><AlertTriangle className="w-3 h-3 mr-1" /> Fix Mistake</span>;
      default:
        return <span className="flex items-center text-blue-600"><Book className="w-3 h-3 mr-1" /> Learning</span>;
    }
  };

  const getNextReviewText = (wordId: string) => {
    const prog = progress[wordId];
    if (!prog) return '-';
    if (prog.status === WordStatus.FixMistakes) return 'ASAP';
    
    const diff = prog.nextReviewDate - Date.now();
    if (diff < 0) return 'Overdue';
    
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days === 0 ? 'Today' : `${days} days`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <h1 className="text-3xl font-bold text-slate-900">Word Library</h1>
        <span className="text-slate-500 text-sm mt-1 md:mt-0">{filteredWords.length} words found</span>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative col-span-1 md:col-span-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search English or Arabic..."
            value={filters.search}
            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
        
        <select 
          value={filters.difficulty} 
          onChange={(e) => setFilters(prev => ({ ...prev, difficulty: e.target.value }))}
          className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none"
        >
          <option value="All">All Difficulties</option>
          <option value={Difficulty.Basic}>Basic</option>
          <option value={Difficulty.Intermediate}>Intermediate</option>
          <option value={Difficulty.Advanced}>Advanced</option>
        </select>

        <select 
          value={filters.topic} 
          onChange={(e) => setFilters(prev => ({ ...prev, topic: e.target.value }))}
          className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none"
        >
          <option value="All">All Topics</option>
          {Object.values(Topic).map(t => <option key={t} value={t}>{t}</option>)}
        </select>

        <select 
          value={filters.status} 
          onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
          className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none"
        >
          <option value="All">All Statuses</option>
          <option value="Not Started">Not Started</option>
          <option value={WordStatus.Learned}>Learned</option>
          <option value={WordStatus.FixMistakes}>Fix Mistakes</option>
        </select>
      </div>

      {/* Table List */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-6 py-4">Word</th>
                <th className="px-6 py-4">Arabic</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Difficulty</th>
                <th className="px-6 py-4">Review Due</th>
                <th className="px-6 py-4">Examples</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredWords.map(word => (
                <tr key={word.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <span className="font-bold text-slate-800">{word.english}</span>
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-600 arabic-text text-base">
                    {word.arabic}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    {getStatusBadge(word.id)}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    <span className={`px-2 py-1 rounded text-xs border ${
                      word.difficulty === Difficulty.Advanced ? 'bg-purple-50 text-purple-700 border-purple-100' :
                      word.difficulty === Difficulty.Intermediate ? 'bg-blue-50 text-blue-700 border-blue-100' :
                      'bg-green-50 text-green-700 border-green-100'
                    }`}>
                      {word.difficulty}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500 font-mono">
                    {getNextReviewText(word.id)}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500 max-w-xs truncate" title={word.example}>
                    {word.example}
                  </td>
                </tr>
              ))}
              {filteredWords.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                    No words found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WordList;