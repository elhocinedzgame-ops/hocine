import React, { useMemo } from 'react';
import { AppState, WordStatus, UserProgress } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Brain, AlertCircle, CheckCircle, Clock } from 'lucide-react';

interface DashboardProps {
  state: AppState;
  onNavigate: (page: string) => void;
  onFilterSelect: (status: string) => void;
}

const COLORS = ['#10b981', '#f59e0b', '#ef4444', '#94a3b8']; // Green, Amber, Red, Slate

const Dashboard: React.FC<DashboardProps> = ({ state, onNavigate, onFilterSelect }) => {
  const stats = useMemo(() => {
    const total = state.words.length;
    const progressValues = Object.values(state.progress) as UserProgress[];
    const learned = progressValues.filter(p => p.status === WordStatus.Learned).length;
    const mistakes = progressValues.filter(p => p.status === WordStatus.FixMistakes).length;
    const unseen = total - Object.keys(state.progress).length;
    // Anything else is 'Learning' (seen but not mastered/mistake) - roughly approximates 'New' in queue logic
    const learning = progressValues.filter(p => p.status === WordStatus.New).length + unseen;

    return { total, learned, mistakes, learning };
  }, [state]);

  const pieData = [
    { name: 'Learned', value: stats.learned, color: '#10b981' }, // emerald-500
    { name: 'To Review', value: stats.learning, color: '#3b82f6' }, // blue-500
    { name: 'Fix Mistakes', value: stats.mistakes, color: '#ef4444' }, // red-500
  ];

  // Calculate upcoming reviews
  const reviewForecast = useMemo(() => {
    const now = Date.now();
    const today = new Date(now).setHours(23, 59, 59, 999);
    const tomorrow = today + 86400000;
    
    let dueToday = 0;
    let dueTomorrow = 0;

    (Object.values(state.progress) as UserProgress[]).forEach(p => {
      if (p.nextReviewDate <= today) dueToday++;
      else if (p.nextReviewDate <= tomorrow) dueTomorrow++;
    });

    return [
      { name: 'Today', count: dueToday },
      { name: 'Tomorrow', count: dueTomorrow },
    ];
  }, [state]);

  const StatCard = ({ title, value, icon: Icon, color, bg, onClick }: any) => (
    <button 
      onClick={onClick}
      disabled={!onClick}
      className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4 text-left w-full transition-transform ${onClick ? 'hover:scale-[1.02] hover:shadow-md cursor-pointer' : ''}`}
    >
      <div className={`p-3 rounded-xl ${bg}`}>
        <Icon className={`w-6 h-6 ${color}`} />
      </div>
      <div>
        <p className="text-sm text-slate-500 font-medium">{title}</p>
        <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
      </div>
    </button>
  );

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500 mt-1">Track your progress and stay consistent.</p>
        </div>
        <button 
          onClick={() => onNavigate('practice')}
          className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-lg font-semibold shadow-lg shadow-teal-600/20 transition-all active:scale-95"
        >
          Start Practice Session
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
           title="Total Words" 
           value={stats.total} 
           icon={Brain} 
           color="text-slate-600" 
           bg="bg-slate-100" 
           onClick={() => onFilterSelect('All')}
        />
        <StatCard 
           title="Learned" 
           value={stats.learned} 
           icon={CheckCircle} 
           color="text-emerald-600" 
           bg="bg-emerald-50" 
           onClick={() => onFilterSelect(WordStatus.Learned)}
        />
        <StatCard 
           title="Needs Review" 
           value={stats.mistakes} 
           icon={AlertCircle} 
           color="text-red-600" 
           bg="bg-red-50" 
           onClick={() => onFilterSelect(WordStatus.FixMistakes)}
        />
        <StatCard 
           title="Total Reviews" 
           value={(Object.values(state.progress) as UserProgress[]).reduce((acc, curr) => acc + curr.reviews, 0)} 
           icon={Clock} 
           color="text-blue-600" 
           bg="bg-blue-50"
           // No navigation for generic 'reviews' count
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pie Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Mastery Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bar Chart Forecast */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Review Forecast</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={reviewForecast}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip cursor={{fill: '#f1f5f9'}} />
                <Bar dataKey="count" fill="#0f766e" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;