import React, { useState, useEffect, useRef } from 'react';
import { Word, UserProgress, Difficulty, Topic } from '../types';
import { getDueWords } from '../services/srsService';
import { Check, RefreshCw, ArrowRight, Sparkles, Volume2, BookOpen, PenTool } from 'lucide-react';
import { getWordExplanation, WordDetails } from '../services/geminiService';

interface PracticeProps {
  words: Word[];
  progress: Record<string, UserProgress>;
  updateProgress: (wordId: string, isCorrect: boolean) => void;
  filters: { difficulty: Difficulty | 'All', topic: Topic | 'All' };
}

type PracticeState = 'input' | 'feedback_correct' | 'feedback_incorrect' | 'completed';

const SESSION_STORAGE_KEY_PREFIX = 'ielts_practice_session_v2_';

const Practice: React.FC<PracticeProps> = ({ words, progress, updateProgress, filters }) => {
  const [sessionQueue, setSessionQueue] = useState<Word[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userInput, setUserInput] = useState('');
  const [gameState, setGameState] = useState<PracticeState>('input');
  
  // AI Data State
  const [aiDetails, setAiDetails] = useState<WordDetails | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize session with Persistence Logic
  useEffect(() => {
    const sessionKey = `${SESSION_STORAGE_KEY_PREFIX}${filters.difficulty}_${filters.topic}`;
    const savedSession = localStorage.getItem(sessionKey);

    let loadedFromSave = false;

    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        // Ensure the saved session is valid and not finished
        if (parsed.queue && parsed.queue.length > 0 && parsed.currentIndex < parsed.queue.length) {
          setSessionQueue(parsed.queue);
          setCurrentIndex(parsed.currentIndex);
          setGameState('input');
          loadedFromSave = true;
        }
      } catch (e) {
        console.error("Failed to load saved session", e);
      }
    }

    if (!loadedFromSave) {
      // Generate new queue if no valid save found
      const due = getDueWords(words, progress, filters.difficulty, filters.topic);
      // Remove limit to include all words in the session
      const newQueue = due; 
      
      setSessionQueue(newQueue);
      setCurrentIndex(0);
      setGameState(newQueue.length > 0 ? 'input' : 'completed');
      
      // Save initial state
      localStorage.setItem(sessionKey, JSON.stringify({ queue: newQueue, currentIndex: 0 }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.difficulty, filters.topic]); // Only re-run if filters change (user explicit action)

  // Persist state whenever index changes
  useEffect(() => {
    if (sessionQueue.length > 0) {
      const sessionKey = `${SESSION_STORAGE_KEY_PREFIX}${filters.difficulty}_${filters.topic}`;
      // If completed, maybe clear it? For now, we keep it until they explicitly restart.
      if (gameState === 'completed') {
        localStorage.removeItem(sessionKey);
      } else {
        localStorage.setItem(sessionKey, JSON.stringify({ queue: sessionQueue, currentIndex }));
      }
    }
  }, [currentIndex, sessionQueue, filters, gameState]);

  // Auto-focus input
  useEffect(() => {
    if (gameState === 'input' && inputRef.current) {
      inputRef.current.focus();
    }
  }, [gameState, currentIndex]);

  const currentWord = sessionQueue[currentIndex];

  // Auto-fetch AI insights when entering feedback state
  useEffect(() => {
    if ((gameState === 'feedback_correct' || gameState === 'feedback_incorrect') && currentWord) {
      const fetchContext = async () => {
        setIsLoadingAi(true);
        const details = await getWordExplanation(currentWord.english, currentWord.example);
        setAiDetails(details);
        setIsLoadingAi(false);
      };
      
      // Only fetch if we have an API key configured (handled by service returning null if not)
      fetchContext();
    }
  }, [gameState, currentWord]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    const isCorrect = userInput.trim().toLowerCase() === currentWord.english.toLowerCase();
    
    // Save progress immediately to DB
    updateProgress(currentWord.id, isCorrect);
    
    setGameState(isCorrect ? 'feedback_correct' : 'feedback_incorrect');
    setAiDetails(null); // Reset previous AI details
  };

  const handleNext = () => {
    if (currentIndex < sessionQueue.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setUserInput('');
      setGameState('input');
      setAiDetails(null);
    } else {
      setGameState('completed');
    }
  };

  const restartSession = () => {
    // Clear storage to force new generation
    const sessionKey = `${SESSION_STORAGE_KEY_PREFIX}${filters.difficulty}_${filters.topic}`;
    localStorage.removeItem(sessionKey);
    window.location.reload(); // Simple reload to trigger the mount logic again cleanly
  };

  const speakWord = () => {
    const utterance = new SpeechSynthesisUtterance(currentWord.english);
    utterance.lang = 'en-GB';
    window.speechSynthesis.speak(utterance);
  };

  const renderSpellingDiff = () => {
    const target = currentWord.english.toLowerCase();
    const attempt = userInput.trim().toLowerCase();
    const maxLength = Math.max(target.length, attempt.length);
    
    const elements = [];
    for (let i = 0; i < maxLength; i++) {
      const tChar = target[i];
      const aChar = attempt[i];
      
      let className = "text-xl font-mono font-bold ";
      if (tChar === aChar) {
        className += "text-emerald-600";
        elements.push(<span key={i} className={className}>{tChar}</span>);
      } else if (!tChar) {
         elements.push(<span key={i} className="text-red-500 bg-red-100 line-through">{aChar}</span>);
      } else if (!aChar) {
         elements.push(<span key={i} className="text-red-500 underline decoration-wavy decoration-red-500">{tChar}</span>);
      } else {
         elements.push(<span key={i} className="text-red-600">{tChar}</span>);
      }
    }
    return <div className="flex space-x-[1px]">{elements}</div>;
  };

  if (gameState === 'completed') {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-white rounded-2xl shadow-sm border border-slate-100">
        <div className="w-20 h-20 bg-teal-100 rounded-full flex items-center justify-center mb-6">
          <Check className="w-10 h-10 text-teal-600" />
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Session Complete!</h2>
        <p className="text-slate-500 mb-8 max-w-md">
          You've reviewed all queued words. Great job keeping up with your vocabulary goals.
        </p>
        <button 
          onClick={restartSession} 
          className="flex items-center px-8 py-4 bg-teal-600 text-white rounded-xl font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-600/20"
        >
          <RefreshCw className="w-5 h-5 mr-2" />
          Start New Session
        </button>
      </div>
    );
  }

  if (!currentWord) return (
    <div className="flex flex-col items-center justify-center h-64 text-slate-500">
      <p>Loading your session...</p>
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto">
      {/* Progress Bar */}
      <div className="flex justify-between text-xs text-slate-400 mb-2 font-medium">
        <span>Word {currentIndex + 1} of {sessionQueue.length}</span>
        <span>{Math.round(((currentIndex) / sessionQueue.length) * 100)}%</span>
      </div>
      <div className="w-full bg-slate-200 h-2 rounded-full mb-8">
        <div 
          className="bg-teal-500 h-2 rounded-full transition-all duration-300"
          style={{ width: `${((currentIndex) / sessionQueue.length) * 100}%` }}
        />
      </div>

      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden min-h-[500px] flex flex-col relative">
        
        {/* Top Card: Arabic Word */}
        <div className="bg-slate-50 p-10 flex flex-col items-center justify-center border-b border-slate-100 relative">
           <div className="absolute top-4 right-4 text-xs font-mono text-slate-300">
             #{currentWord.id}
           </div>
          <span className="inline-block px-3 py-1 bg-slate-200 text-slate-600 text-xs rounded-full font-medium mb-4 uppercase tracking-wider">
            {currentWord.topic}
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-800 arabic-text mb-2 text-center">
            {currentWord.arabic}
          </h2>
          <p className="text-slate-400 text-sm font-medium">Translate to English</p>
        </div>

        {/* Input Area / Feedback Area */}
        <div className="p-8 flex-1 flex flex-col items-center w-full">
          
          {gameState === 'input' && (
            <form onSubmit={handleSubmit} className="w-full max-w-md flex flex-col items-center space-y-6 mt-4">
              <input
                ref={inputRef}
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Type the English word..."
                className="w-full text-center text-3xl font-medium p-4 border-b-2 border-slate-200 focus:border-teal-500 focus:outline-none transition-colors placeholder:text-slate-300"
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
              />
              <div className="flex w-full space-x-3">
                 <button 
                  type="button"
                  onClick={handleNext}
                  className="px-6 py-4 bg-slate-100 text-slate-500 rounded-xl font-bold text-lg hover:bg-slate-200 transition-colors"
                >
                  Skip
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-4 bg-teal-600 text-white rounded-xl font-bold text-lg hover:bg-teal-700 transition-transform active:scale-[0.98] shadow-md"
                >
                  Check Answer
                </button>
              </div>
            </form>
          )}

          {gameState !== 'input' && (
            <div className="w-full animate-fade-in flex flex-col items-center">
              
              <div className="flex items-center space-x-2 mb-2">
                 <h3 className={`text-2xl font-bold ${gameState === 'feedback_correct' ? 'text-emerald-600' : 'text-red-600'}`}>
                    {gameState === 'feedback_correct' ? 'Correct!' : 'Incorrect'}
                 </h3>
                 <button onClick={speakWord} className="p-2 text-slate-400 hover:text-teal-600 transition-colors">
                    <Volume2 className="w-5 h-5" />
                 </button>
              </div>
              
              <div className="mb-6">
                 {gameState === 'feedback_correct' ? (
                   <span className="text-3xl font-bold text-slate-800">{currentWord.english}</span>
                 ) : (
                   renderSpellingDiff()
                 )}
              </div>

              {/* Context Cards Grid */}
              <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                 
                 {/* Synonyms Card */}
                 <div className="md:col-span-2 bg-slate-50 rounded-xl p-4 border border-slate-100">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2 flex items-center">
                       <Sparkles className="w-3 h-3 mr-1" /> Synonyms
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {currentWord.synonyms.map(syn => (
                        <span key={syn} className="px-3 py-1 bg-white border border-slate-200 text-slate-700 rounded-lg text-sm font-medium">
                          {syn}
                        </span>
                      ))}
                      {/* Add AI synonyms if available and distinct */}
                      {aiDetails?.synonyms?.map(syn => {
                         if (!currentWord.synonyms.includes(syn)) {
                           return (
                              <span key={syn} className="px-3 py-1 bg-purple-50 border border-purple-100 text-purple-700 rounded-lg text-sm font-medium">
                                {syn} (AI)
                              </span>
                           );
                         }
                         return null;
                      })}
                    </div>
                 </div>

                 {/* Task 1 Usage Card */}
                 <div className="bg-blue-50/50 rounded-xl p-4 border border-blue-100">
                    <h4 className="text-xs font-bold text-blue-600 uppercase tracking-wide mb-2 flex items-center">
                       <BookOpen className="w-3 h-3 mr-1" /> Task 1 Usage
                    </h4>
                    {isLoadingAi ? (
                       <div className="animate-pulse h-12 bg-blue-100/50 rounded"></div>
                    ) : (
                       <p className="text-sm text-slate-700 italic">
                          {aiDetails?.task1Usage || "Loading context..."}
                       </p>
                    )}
                 </div>

                 {/* Task 2 Usage Card */}
                 <div className="bg-teal-50/50 rounded-xl p-4 border border-teal-100">
                    <h4 className="text-xs font-bold text-teal-600 uppercase tracking-wide mb-2 flex items-center">
                       <PenTool className="w-3 h-3 mr-1" /> Task 2 Usage
                    </h4>
                    {isLoadingAi ? (
                       <div className="animate-pulse h-12 bg-teal-100/50 rounded"></div>
                    ) : (
                       <p className="text-sm text-slate-700 italic">
                          {aiDetails?.task2Usage || currentWord.example}
                       </p>
                    )}
                 </div>
              </div>
              
              {/* Nuance Note */}
              {aiDetails?.nuance && (
                <div className="w-full text-xs text-slate-500 text-center mb-6">
                   <span className="font-semibold">Note:</span> {aiDetails.nuance}
                </div>
              )}

              <button 
                onClick={handleNext}
                autoFocus
                className="w-full py-4 bg-slate-900 text-white rounded-xl font-bold text-lg hover:bg-slate-800 transition-colors flex items-center justify-center group"
              >
                <span>Continue</span>
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Practice;